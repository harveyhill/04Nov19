/*  This file holds all the JavaScript functions my webpage uses.
*/

// Button handler for switching tabs on the page
function openTab (evt, tabName) 
{   let i, tabContent;
    tabContent = document.querySelectorAll(".tabcontent");
    // Hide all tabs
    for ( i = 0 ; i < tabContent.length ; i++ ) {   tabContent[i].style.display = "none"; }
    // Display selected tab
    document.querySelector("#" + tabName).style.display = "block";
}

// Open default tab
openTab(null, "about");

/*  JSChallengeHandler
    Handles all JavaScript Challenge button clicks by routing them through a switch.
    All HTML input objects have the name "#{input || output}_{challenge}", so they're easy to build.
*/
function JSChallengeHandler (evt, challenge)
{   let input = document.querySelector("#input_" + challenge).value;
    switch (challenge)
    {   case "fib" :
            document.querySelector("#output_" + challenge).value = fib(input);
            break;
        case "rev" :
            document.querySelector("#output_" + challenge).value = reverseStr(input);
            break;
        case "fac" :
            document.querySelector("#output_" + challenge).value = factorial(input);
            break;
        case "sub" :
            let offset = document.querySelector("#input_" + challenge + "Offset").value;
            let length = document.querySelector("#input_" + challenge + "Length").value;
            document.querySelector("#output_" + challenge).value = substring(input, length, offset);
            break;
        case "even" :
            document.querySelector("#output_" + challenge).value = isEven( parseInt(input) );
            break;
        case "pal" :
            document.querySelector("#output_" + challenge).value = isPalindrome(input);
            break;
        case "spli" :
            input = input.trim().split(',')             // Convert input from string to array
            document.querySelector("#output_" + challenge).value = spliceElement(input);
            break;
        case "bub" :
            input = input.trim().split(',');            // Convert input from string to array
            for ( let i = 0 ; i < input.length ; i++ )
                input[i] = parseInt(input[i]);          // Convert input from str array to int array
            document.querySelector("#output_" + challenge).innerHTML = bubbleSort(input);
            break;
        case "desc" :
            document.querySelector("#output_" + challenge).value = descOrder(input);
            break;
        case "sha" :
            let shapetype;
            let radios = document.getElementsByName("shape");
            for ( let i of radios )
                if ( i.checked ) shapetype = i.value;   // Get radio button input
            let shapeheight = document.querySelector("#input_shapeheight").value;
            printShape(shapetype, parseInt(shapeheight), input);
            break;
    }
}

/*  1. Fibonacci 
    Define function: fib(n) 
    Return the nth number in the fibonacci sequence.
*/
function fib (n)                                        // Takes string arg
{   if ( n < 1 ) return 0;                              // Returns 0 if a non number val is passed
    if ( n == 1 ) return 1;
    return fib(n-1) + fib(n-2);
}

/*  2. Bubble Sort
    Define function: bubbleSort(numArray)
    Use the bubble sort algorithm to sort the array.
    Return the sorted array.
*/

function bubbleSort(numArray)                           // Takes array of ints as arg
{   for ( let i = 0 ; i < numArray.length - 1 ; i++ )
        for ( let j = 0 ; j < numArray.length - i - 1 ; j++ )
            if ( numArray[j] < numArray[j + 1] )
            {   console.log( "Swap " + numArray[j] + " and " + numArray[j + 1] );
                let temp = numArray[j];
                numArray[j] = numArray[j + 1];
                numArray[j + 1] = temp;
            }
    return numArray;
}

/*  3. Reverse String
    Define function: reverseStr(someStr)
    Reverse and return the String.
*/

function reverseStr (someStr)                           // Takes string arg
{   let output = "";
    for (let i = 0 ; i < someStr.length ; i++ )
        output = someStr[i] + output;
    return output;
}

/*  4. Factorial
    Define function: factorial(someNum)
    Use recursion to compute and return the factorial of someNum.
*/

function factorial (someNum)                            // Takes string arg
{   if (someNum <= 1) return 1;                         // Returns 1 if a non number is passed
    return someNum * factorial(someNum - 1);
}

/*  5. Substring
    Define function substring(someStr, length, offset)
    Return the substring contained between offset and (offset + length) inclusively.
    If incorrect input is entered, use the alert function and describe why the input was incorrect.
*/

function substring ( someStr, length, offset )          // Takes 3 strings as args
{   length = parseInt(length); offset = parseInt(offset);
    if (length == NaN) alert("Length must be a number!");
    if (offset == NaN) alert("Offset must be a number!");
    return someStr.slice(offset, offset + length);
}

/*  6. Even Number
    Define function: isEven(someNum)
    Return true if even, false if odd.
    Do not use % operator.
*/

function isEven (someNum)                               // Takes int arg
{   return ( someNum / 2 == (someNum / 2).toFixed(0) );
}

/*  7. Palindrome
    Define function isPalindrome(someStr)
    Return true if someStr is a palindrome, otherwise return false
*/

function isPalindrome (someStr)                         // Takes string arg
{   for ( let i = 0 ; i < someStr.length / 2 ; i++ )    // length field is 1 above final index
        if ( someStr[i] != someStr[someStr.length - i - 1] )
            return false;
    return true;
}

/*  8. Shapes
    Define function: printShape(shape, height, character)
    shape is a String and is either "Square", "Triangle", "Diamond".
    height is a Number and is the height of the shape. Assume the number is odd.
    character is a String that represents the contents of the shape.
    Assume this String contains just one character.
    Use a switch statement to determine which shape was passed in.
    Use the console.log function to print the desired shape.

    Example for printShape("Square", 3, "%");

    %%%
    %%%
    %%%

    Example for printShape("Triangle", 3, "$");

    $
    $$
    $$$

    Example for printShape("Diamond", 5, "*");

      *
     ***
    *****
     ***
      * 
*/

function printShape (shape, height, character)          // Takes string, int, string args
{   let i, j;
    let shaperow = "";
    character = character.charAt(0);                    // Take the first char offered if multiple
    switch (shape)                                      // Switch through radio buttons
    {   case "Square" :
            for ( i = 0 ; i < height ; i++ )
                shaperow += character;                  // Height = length, so shaperow length = height 
            for ( i = 0 ; i < height ; i++ )
                console.log(shaperow);
            break;
        case "Triangle" : 
            for ( i = 0 ; i < height ; i++ )
            {   shaperow += character;                  // Shaperow gets 1 bigger each iteration
                console.log(shaperow);
            }
            break;
        case "Diamond" :
            let center = ( height - 1 ) / 2;            // Find middle of diamond
            for ( i = 0 ; i < height ; i++ )
            {   shaperow = '';                          // Build row by row, emptying every time
                for ( j = 0 ; j < height ; j++ )        // Use conditions judging distance from (j,i) to center
                {   if  (   j >= center - i &&          // Think of j as x-axis and i as y-axis
                            j <= center + i &&
                            j >= i - center && 
                            j <= 3 * center - i
                        )
                        shaperow += character;          // If true, add a character
                    else shaperow += ' ';               // If false, add whitespace
                }
                console.log(shaperow);                  // Print the row each time you build it
            }
            break;
    }

}

/*  11. Splice Element
    Define function spliceElement(someArr)
    Print length
    Splice the third element in the array.
    Print length
    The lengths should be one less than the original length.
*/

function spliceElement (someArr)                        // Takes array of string args
{   document.querySelector('#output_spliBefore').value = someArr.length;
    someArr.splice(2, 1);
    return someArr.length;
}

/*  15. Descending order
    Your task is to make a function that can take any non-negative 
    integer as a argument and return it with its digits in descending 
    order. Essentially, rearrange the digits to create the highest possible number.
*/

function descOrder (n)                                  // Takes int
{   let arrayN = [];
    if (n < 1 ) return "Number must be positive!";
    while ( n > 0 )                                     // Converts int to array of 1-digit ints
    {   arrayN.push(n % 10);
        n = (n - (n % 10) ) / 10;
    }
    arrayN = bubbleSort(arrayN);                        // Sort array with bubbleSort from challenge 2
    for ( let i = 0 ; i < arrayN.length ; i++ )         // Convert array back to int
        n = (n * 10) + arrayN[i];
    return n;
}

/*  AJAX and API Consumption
	
	* Using AJAX, make a callout to any work appropriate API.
    * Update a html page, using the information obtained from the API.
*/
async function spotifyAuthRedirect (evt)
{   // Hold string of the redirect page URL in several vars for better documentation
    const authEndpoint = 'https://accounts.spotify.com/authorize';
    const clientID = 'ca6b26127abe4c1da78e566344e85272';// Spotify for Dev registration
    const redirectUri = 'http://localhost:3000';        // Local server with code in myServer/views/index.ejs
    const scopes = [ 'user-top-read' ];                 // Scope of the permission we're seeking
    const redirect  = authEndpoint 
                    + '?client_id=' + clientID
                    + '&redirect_uri=' + redirectUri
                    + '&scope=' + scopes.join('%20')
                    + '&response_type=token&show_dialog=true';
    // Send client to authenticate with Spotify
    // If successful, send to localhost:3000 with an access token in the URL after the hash
    window.location = redirect;
}
