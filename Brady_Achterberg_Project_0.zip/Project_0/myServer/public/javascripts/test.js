function hello(evt)
{   // mine the webpage url for the access token
    // example url: http://localhost:3000/#access_token=BQCvfp6Bhj3LdlJ-QT-rUDH-2vFmCFrfFxHZ9-HVYwdmTAT0e-xSDRN7-CKzfjNpwzyX3JjhQM4IP6hC7799xNkhjjGfcQHqI-coEZj395DK1VyAtxd9KtARwjr5eiu23RwJAyXYz0Vs1t0g73hgrbM&token_type=Bearer&expires_in=3600
    const accessToken = window.location     // get webpage location
                            .hash           // get url after the '#'
                            .split('&')     // split hash by '&' into access token, token type, expires-in
                            [0]             // take the first slice aka access token
                            .substring(14,);// remove the label 'access-token='
        
    console.log(accessToken); 

    // make an api request
    // this is literally the only part that was required
    let xhr = new XMLHttpRequest();
    xhr.responseType = 'json';
    xhr.onload = function()
    {   console.log('Successfully loaded!')
        console.log(xhr.response);
        for (i of xhr.response.items)
            document.querySelector("#list").innerHTML += i.name + "<br>";
    }

    xhr.open('GET', 'https://api.spotify.com/v1/me/top/tracks', true);
    xhr.setRequestHeader('Authorization', 'Bearer ' + accessToken);
    xhr.send();
}

console.log('Hello world!');